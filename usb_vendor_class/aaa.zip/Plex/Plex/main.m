//
//  main.m
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
