//
//  AppDelegate.m
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#import "AppDelegate.h"
#include "UsbDriver.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    g_dev_handle = open_usb_device(VENDOR_ID, PRODUCT_ID);
    if(g_dev_handle == NULL)
        perror("open usb device error");
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    close_usb_device(g_dev_handle);
}

@end
