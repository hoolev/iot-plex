//
//  UserSignature.h
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#ifndef __Plex__UserSignature__
#define __Plex__UserSignature__

#include <stdio.h>

typedef struct {
    uint8_t major_version;
    uint8_t minor_version;
    uint8_t fixture_type;
    uint16_t size;
    uint16_t board_serial_number;
    uint16_t fixture_serial_number;
    uint32_t timestamp;
    uint32_t checksum;
}plex_user_signature;

int get_user_signature(plex_user_signature *signature);
int set_user_signature(plex_user_signature *signature);

#endif /* defined(__Plex__UserSignature__) */
