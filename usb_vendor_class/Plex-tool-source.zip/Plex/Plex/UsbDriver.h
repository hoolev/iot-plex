//
//  UsbDriver.h
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#ifndef __Plex__UsbDriver__
#define __Plex__UsbDriver__

#include <stdio.h>
#include "libusb.h"

#define VENDOR_ID 1452
#define PRODUCT_ID 43981



libusb_device_handle *open_usb_device(uint16_t vendor_id, uint16_t product_id);

int send_to_device(libusb_device_handle *device_handle, uint8_t *cmd, int length);
int recv_from_device(libusb_device_handle *device_handle,uint8_t *data, int length);

void close_usb_device(libusb_device_handle *dev_handle);

#endif /* defined(__Plex__UsbDriver__) */
