//
//  ViewController.m
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#import "ViewController.h"
#import "UserSignature.h"

@interface ViewController()
@property (weak) IBOutlet NSTextField *majorVersion;
@property (weak) IBOutlet NSTextField *minorVersion;
@property (weak) IBOutlet NSTextField *size;

@property (weak) IBOutlet NSTextField *fixtureType;
@property (weak) IBOutlet NSTextField *fixtureSerialNumber;
@property (weak) IBOutlet NSTextField *boardSerialNumber;
@property (weak) IBOutlet NSTextField *timestamp;
@property (weak) IBOutlet NSTextField *checksum;


@end

@implementation ViewController

- (IBAction)readUserSignature:(NSButton *)sender {
    plex_user_signature signature;
    if(get_user_signature(&signature) < 0)
    {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setAlertStyle:NSInformationalAlertStyle];
        [alert setMessageText:@"Read user signature failed!"];
        [alert runModal];
    }
    else
    {
        time_t tm = signature.timestamp;
        self.majorVersion.integerValue = signature.major_version;
        self.minorVersion.integerValue = signature.minor_version;
        self.size.integerValue = signature.size;
        self.fixtureType.integerValue = signature.fixture_type;
        //self.fixtureSerialNumber.integerValue = signature.fixture_serial_number;
        self.fixtureSerialNumber.stringValue = [NSString stringWithFormat:@"%u",signature.fixture_serial_number];
        self.boardSerialNumber.integerValue = signature.board_serial_number;
        self.timestamp.stringValue = [NSString stringWithCString:ctime(&tm) encoding:NSUTF8StringEncoding];
        self.checksum.integerValue = signature.checksum;
    }
}
- (IBAction)writeUserSignature:(NSButton *)sender {
    plex_user_signature signature;
    
    signature.major_version = self.majorVersion.integerValue;
    signature.minor_version = self.minorVersion.integerValue;
    signature.size = self.size.integerValue;
    signature.fixture_type = self.fixtureType.integerValue;
    signature.fixture_serial_number = self.fixtureSerialNumber.integerValue;
    signature.board_serial_number = self.boardSerialNumber.integerValue;
    
    if(set_user_signature(&signature) < 0)
    {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setAlertStyle:NSWarningAlertStyle];
        [alert setMessageText:@"Save user signature failed!"];
        [alert runModal];
    } else {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setAlertStyle:NSInformationalAlertStyle];
        [alert setMessageText:@"Save user signature successful!"];
        [alert runModal];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
