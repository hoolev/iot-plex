//
//  UsbDriver.c
//  Plex
//
//  Created by seeing on 15/10/15.
//  Copyright (c) 2015年 seeing. All rights reserved.
//

#include "UsbDriver.h"

static unsigned char udi_vendor_ep_bulk_in;
static unsigned char udi_vendor_ep_bulk_out;

static struct libusb_config_descriptor *conf_desc = NULL;
static libusb_context *ctx = NULL;

int send_to_device(libusb_device_handle *device_handle, uint8_t *cmd, int length)
{
    int transferred;
    if (0> libusb_bulk_transfer( device_handle,
                                udi_vendor_ep_bulk_out,
                                cmd,
                                length,
                                &transferred,
                                1000)) {
        return -1;
    }
    
    return 0;
}

int recv_from_device(libusb_device_handle *device_handle,uint8_t *data, int length)
{
    int transferred;
    if (0> libusb_bulk_transfer( device_handle,
                                udi_vendor_ep_bulk_in,
                                data,
                                length,
                                &transferred,
                                10000)) {
        
        
        return -1;
    }
    
    return 0;
}

libusb_device_handle *open_usb_device(uint16_t vendor_id, uint16_t product_id)
{
    libusb_device *dev;
    unsigned char nb_ep = 0;
    libusb_device_handle *dev_handle;
    struct libusb_endpoint_descriptor *endpoints;
    
    if(libusb_init(&ctx) < 0) //initialize the library for the session we just declared
    {
        perror("Init Error\n"); //there was an error
        return NULL;
    }
    
    libusb_set_debug(ctx, LIBUSB_LOG_LEVEL_INFO);
    dev_handle = libusb_open_device_with_vid_pid(ctx, vendor_id, product_id);
    if(dev_handle == NULL)
        return NULL;
    
    dev = libusb_get_device(dev_handle);
    libusb_get_config_descriptor(dev, 0, &conf_desc);
    
    udi_vendor_ep_bulk_in = 0;
    udi_vendor_ep_bulk_out = 0;
    
    
    if(1 == conf_desc->interface->num_altsetting)
    {
        nb_ep = conf_desc->interface->altsetting[0].bNumEndpoints;
        endpoints = conf_desc->interface->altsetting[0].endpoint;
    }
    else
    {
        nb_ep = conf_desc->interface->altsetting[1].bNumEndpoints;
        endpoints = conf_desc->interface->altsetting[1].endpoint;
    }
    
    while (nb_ep)
    {
        nb_ep--;
        
        unsigned char ep_type = endpoints[nb_ep].bmAttributes & LIBUSB_TRANSFER_TYPE_MASK;
        unsigned char ep_add = endpoints[nb_ep].bEndpointAddress;
        
        if(ep_type == LIBUSB_TRANSFER_TYPE_BULK)
        {
            if (ep_add & LIBUSB_ENDPOINT_IN)
                udi_vendor_ep_bulk_in = endpoints[nb_ep].bEndpointAddress;
            else
                udi_vendor_ep_bulk_out= endpoints[nb_ep].bEndpointAddress;
         }
    }

    if(libusb_set_configuration(dev_handle, 1) < 0)
    {
        printf("error: setting config 1 failed\n");
        libusb_close(dev_handle);
        return NULL;
    }
    
    if(libusb_claim_interface(dev_handle, 0) < 0)
    {
        printf("error: claiming interface 0 failed\n");
        libusb_close(dev_handle);
        return NULL;
    }
    
    if(1 != conf_desc->interface->num_altsetting)
    {
        if(libusb_set_interface_alt_setting(dev_handle, 0,1) < 0)
        {
            printf("error: set alternate 1 interface 0 failed\n");
            libusb_close(dev_handle);
            return NULL;
        }
    }
    
    return dev_handle;
}

void close_usb_device(libusb_device_handle *dev_handle)
{
    libusb_free_config_descriptor(conf_desc);
    libusb_close(dev_handle);
    libusb_exit(ctx);
}

